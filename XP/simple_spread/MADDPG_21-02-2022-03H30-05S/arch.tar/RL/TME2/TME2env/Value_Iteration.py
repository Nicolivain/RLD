import matplotlib

matplotlib.use("TkAgg")
import gym
import gridworld
from gym import wrappers, logger
import numpy as np
import copy


class Value_Iteration(object):
    """Best but not simplest agent"""

    def __init__(self, action_space, values = []):
        states = env.getMDP()[0]
        self.action_space = action_space
        self.values = np.array([[0.1]+[0 for i in range(len(states)-1)],[0 for i in range(len(states))]]) #initialization for V
        self.pi = np.zeros(len(states))


    def act(self, observation):
        state = env.getStateFromObs(observation) #obligé d'utiliser le env. car c'est une méthode de GridWorld
        return self.pi[state]
        
    # def getStateFromObs(self,obs):
    #     states,p=self.getMDP()
    #     return self.states[GridworldEnv.state2str(obs)]

if __name__ == '__main__':


    env = gym.make("gridworld-v0")
    env.setPlan("gridworldPlans/plan0.txt", {0: -0.001, 3: 1, 4: 1, 5: -1, 6: -1})
    states, mdp = env.getMDP()  # recupere le mdp et la liste d'etats
    env.seed(0)  # Initialise le seed du pseudo-random

    # Execution avec un Agent
    # Détermination de la politique pi par Value_Iteration
    agent = Value_Iteration(env.action_space)

    epsilon = 1e-7
    gamma = 0.99

    while True :
        for state,transi in list(mdp.items()):  # un dico
            best_action = list(transi.keys())[0]  # meilleure action par défaut = la première
            L = [np.sum([elem[0] * (elem[2] + gamma*agent.values[-1][elem[1]]) for elem in transi[best_action]])]  # somme pour la première action
            for action in list(transi.keys())[1:]:  # on ne teste pas la première qui est déjà traitée
                L.append(np.sum([elem[0] * (elem[2] + gamma*agent.values[-1][elem[1]]) for elem in transi[action]]))
            agent.values[-2][state] = agent.values[-1][state]
            agent.values[-1][state] = np.max(L)
        if np.linalg.norm(agent.values[-1] - agent.values[-2]) <= epsilon:
            break

    V = agent.values[-1]

    for state,transi in list(mdp.items()):
        l = []
        for action in list(transi.keys()):
            coeff = np.sum([elem[0] * (elem[2] + gamma*V[[elem[1]]]) for elem in transi[action]])
            l.append(coeff)
        agent.pi[state] = np.argmax(l)

    # Affichage de 1000 épisodes :
    moy = 0
    obs = env.reset()
    episode_count = 1000
    reward = 0
    done = False

    for i in range(episode_count):
        obs = env.reset()
        env.verbose = (i % 100 == 0 and i > 0)  # afficher 1 episode sur 100
        if env.verbose:
            env.render()
        j = 0
        rsum = 0
        while True:
            action = agent.act(obs)
            obs, reward, done, _ = env.step(action)
            #print(obs, reward)
            rsum += reward
            moy += rsum
            j += 1
            if env.verbose:
                env.render()
            if done:
                print("Episode : " + str(i) + " rsum=" + str(rsum) + ", " + str(j) + " actions")
                break

    print("done")
    # print(moy/float(episode_count))
    env.close()