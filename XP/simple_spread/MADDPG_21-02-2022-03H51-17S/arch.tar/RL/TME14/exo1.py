from utils import *

class transfo_aff(FlowModule):
    def __init__(self, dim, s, t):
        super().__init__()
        self.dim = dim
        self.s = torch.ones_like(s, requires_grad = True)
        self.t = torch.ones_like(t, requires_grad = True)

    def invf(self, y) -> Tuple[torch.Tensor, torch.Tensor]:
        """Returns f^-1(x) and log |det J_f^-1(x)|"""
        return (y-self.t)*torch.exp(-self.s),-torch.sum(self.s)
        

    def f(self, x) -> Tuple[torch.Tensor, torch.Tensor]:
        """Returns f(x) and log |det J_f(x)|"""
        return x*torch.exp(self.s)+self.t, torch.sum(self.s)


if __name__=="main" :
