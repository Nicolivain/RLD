import matplotlib

matplotlib.use("TkAgg")
import gym
import gridworld
from gym import wrappers, logger
import numpy as np
import copy


class Policy_Iteration(object):

    def __init__(self, action_space, values=[]):
        states = env.getMDP()[0]
        self.action_space = action_space
        self.values = np.zeros(len(states), dtype=float) # initialization for V
        self.pi = np.zeros(len(states)) #np.random.randint(0,4,len(states)) #initialisation aléatoire de pi

    def act(self, observation):
        state = env.getStateFromObs(observation)  # obligé d'utiliser le env. car c'est une méthode de GridWorld
        return self.pi[state]

    # def getStateFromObs(self,obs):
    #     states,p=self.getMDP()
    #     return self.states[GridworldEnv.state2str(obs)]


if __name__ == '__main__':

    env = gym.make("gridworld-v0")
    env.setPlan("gridworldPlans/plan0.txt", {0: -0.001, 3: 1, 4: 1, 5: -1, 6: -1})
    states, mdp = env.getMDP()  # recupere le mdp et la liste d'etats
    env.seed(0)  # Initialise le seed du pseudo-random

    # Execution avec un Agent
    # Détermination de la politique pi par Policy_Iteration
    agent = Policy_Iteration(env.action_space)

    epsilon = 1e-10
    gamma = 0.99
    count=0

    #Boucle pour déterminer la politique optimale :

    while True :
        agent.values = np.zeros(len(states)) # initialisation aléatoire de V_0
        count += 1
        while True :
            V = agent.values.copy()
            for state, transi in list(mdp.items()):  # parcours d'un dico
                #if (agent.pi[state] in transi.keys()) :
                agent.values[state] = np.sum([elem[0] * (elem[2] + gamma*agent.values[elem[1]]) for elem in transi[agent.pi[state]]])
            if np.linalg.norm(agent.values - V) < epsilon :
                break
        pi = agent.pi.copy()
        for state, transi in list(mdp.items()):
            l = []
            for action in list(transi.keys()):
                l.append(np.sum([elem[0] * (elem[2] + gamma * agent.values[elem[1]]) for elem in transi[action]]))
            agent.pi[state] = np.argmax(l)
        print(pi, agent.pi)
        if (agent.pi == pi).all():
            break

    # Affichage de 1000 épisodes :
    moy = 0
    obs = env.reset()
    episode_count = 1000
    reward = 0
    done = False

    for i in range(episode_count):
        obs = env.reset()
        env.verbose = (i % 100 == 0 and i > 0)  # afficher 1 episode sur 100
        if env.verbose:
            env.render()
        j = 0
        rsum = 0
        while True:
            action = agent.act(obs)
            obs, reward, done, _ = env.step(action)
            # print(obs, reward)
            rsum += reward
            moy += rsum
            j += 1
            if env.verbose:
                env.render()
            if done:
                print("Episode : " + str(i) + " rsum=" + str(rsum) + ", " + str(j) + " actions")
                break

    print("done")
    # print(moy/float(episode_count))
    env.close()