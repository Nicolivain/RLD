import argparse
import sys
import matplotlib
#matplotlib.use("Qt5agg")
matplotlib.use("TkAgg")
import gym
import gridworld
import torch
from memory import *
from utils import *
from core import *
from torch.utils.tensorboard import SummaryWriter
#import highway_env
from matplotlib import pyplot as plt
import yaml
from datetime import datetime
from core import NN
import torch.nn.functional as F
import copy


class A2C(object):
    '''montée de gradient theta <- theta + alpha*grad{J(theta)}'''
    def __init__(self, env, opt, gamma=0.9, mem_size = 10000): #inSize  = nombre de couples (s,a,s',r,final) = nombre de trajectoires en mémoire // #outSize = 5 (cardinal du couple (s,a,s',r,final)
        self.opt=opt
        self.env=env
        self.gamma = gamma
        self.mem = Memory(mem_size, prior=False, p_upper=1., epsilon=.01,alpha=1,beta=1) #on génère une mémoire initiale de taille mem_size
        if opt.fromFile is not None:
            self.load(opt.fromFile)
        self.action_space = env.action_space
        self.featureExtractor = opt.featExtractor(env) #pour le randomAgent, c'est l'identité ; pour d'autres environnement ce sera utile pour l'extraction des observations
        self.test=False
        self.explo = 0.1
        self.decay = 0.9
        self.nbEvents=0
        #print(self.env.action_space.shape[0], self.featureExtractor.outSize)
        self.actor = NN(self.featureExtractor.outSize,self.action_space.n, layers = [30,30], activation = torch.tanh) #actor va renvoyer la distribution pour les actions
        self.value = NN(self.featureExtractor.outsize, self.action_space.n, layers = [30,30], activation = torch.tanh) #va apprendre selon les transitions
        self.loss = F.smooth_l1_loss
        #self.Qhat = NN(inSize, outSize, layers=[], finalActivation=None, activation=torch.tanh,dropout=0.0)
        self.optim = torch.optim.Adam(self.actor.parameters(), lr=0.0003) #le adam est self adaptatif sur le leraning rate

    def act(self, obs):  # on fait l'epsilon greedy
        if np.random.rand() < self.explo:
            return self.action_space.sample()
        else:
            self.explo *= self.decay  # on fait décroitre l'exploration
            return torch.argmax(
                self.Q(torch.tensor(obs))).item()  # on doit renvoyer l'action avec le plus grand reward associé

    # sauvegarde du modèle
    def save(self,outputDir):
        pass

    # chargement du modèle.
    def load(self,inputDir):
        pass

    # apprentissage de l'agent
    def learn(self, ob, action, new_ob, reward, done, it):
        # Si l'agent est en mode de test, on n'entraîne pas
        bs = 100
        if self.test or (self.mem.nentities <= bs):
            return
        #sinon on apprend avec la descente de gradient
        self.optim.zero_grad()
        _, _, batch = self.mem.sample(bs) #la méthode sample de la classe mémoire renvoie un tuple (mask, 0, mem[mask]) (on veut que la 3e valeur)
        states, actions, rewards, new_states, dones = self.mem.separate_out_data_types(batch)
        target = rewards + self.gamma*torch.max(self.Q(new_states))*(1-dones)
        pred = self.Q(states)
        l = self.loss(pred, target)
        logger.direct_write("Loss/Train/DQN_1Net", l, it)
        l.backward()
        self.optim.step() #on calcule les gradients

    # enregistrement de la transition pour exploitation par learn ulterieure
    def store(self, ob, action, new_ob, reward, done, it):
        # Si l'agent est en mode de test, on n'enregistre pas la transition
        if not self.test:
            # si on atteint la taille max d'episode en apprentissage, alors done ne devrait pas etre a true (episode pas vraiment fini dans l'environnement)
            if it == self.opt.maxLengthTrain:
                print("undone")
                done=False
            tr = (ob, action, reward, new_ob, done)
            self.lastTransition=tr #ici on n'enregistre que la derniere transition pour traitement immédiat, mais on pourrait enregistrer dans une structure de buffer (c'est l'interet de memory.py)
            _ = self.mem.store(self.lastTransition) #ajout dans la mémoire
    # retourne vrai si c'est le moment d'entraîner l'agent.
    # Dans cette version retourne vrai tous les freqoptim evenements
    # Mais on pourrait retourner vrai seulement si done pour s'entraîner seulement en fin d'épisode

    def timeToLearn(self,done):
        if self.test:
            return False
        self.nbEvents+=1
        return self.nbEvents%self.opt.freqOptim == 0


class DQN_target_network(object):
    """The world's simplest agent!"""

    def __init__(self, env, opt, gamma=0.9, mem_size = 10000): #inSize  = nombre de couples (s,a,s',r,final) = nombre de trajectoires en mémoire // #outSize = 5 (cardinal du couple (s,a,s',r,final)
        self.opt=opt
        self.env=env
        self.gamma = gamma
        self.mem = Memory(mem_size, prior=False, p_upper=1., epsilon=.01,alpha=1,beta=1) #on génère une mémoire initiale de taille mem_size
        if opt.fromFile is not None:
            self.load(opt.fromFile)
        self.action_space = env.action_space
        self.featureExtractor = opt.featExtractor(env) #pour le randomAgent, c'est l'identité ; pour d'autres environnement ce sera utile pour l'extraction des observations
        self.test=False
        self.nbEvents=0
        self.explo = 0.1
        self.decay = 0.9999
        #print(self.env.action_space.shape[0], self.featureExtractor.outSize)
        self.Q = NN(self.featureExtractor.outSize,self.action_space.n, layers = [200]) #à Q(s) on renvoie les rewards dans chaque actions possibles
        self.Qhat = copy.deepcopy(self.Q)
        self.C = 10
        self.step = 0
        self.loss = F.smooth_l1_loss
        self.optim = torch.optim.Adam(self.Q.parameters(), lr=0.0003)

    def act(self, obs): #on fait l'epsilon greedy
        if np.random.rand() < self.explo :
            return self.action_space.sample()
        else :
            self.explo*=self.decay #on fait décroitre l'exploration
            return torch.argmax(self.Q(torch.tensor(obs))).item() #on doit renvoyer l'action avec le plus grand reward associé

    # sauvegarde du modèle
    def save(self,outputDir):
        pass

    # chargement du modèle.
    def load(self,inputDir):
        pass

    # apprentissage de l'agent
    def learn(self, ob, action, new_ob, reward, done, it):
        # Si l'agent est en mode de test, on n'entraîne pas
        bs = 100
        if self.test or (self.mem.nentities <= bs) :
            return

        #sinon on apprend avec la descente de gradient
        self.optim.zero_grad()
        _, _, batch = self.mem.sample(bs) #la méthode sample de la classe mémoire renvoie un tuple (mask, 0, mem[mask]) (on veut que la 3e valeur)
        states, actions, rewards, new_states, dones = self.mem.separate_out_data_types(batch)
        with torch.no_grad() :
            yhat = rewards*dones + self.gamma*torch.max(self.Qhat(new_states))*(1-dones)
        qValue = self.Q(states)
        l = self.loss(yhat, qValue)
        logger.direct_write("Loss/Train/DQN_Target", l, it)
        l.backward()
        self.optim.step() #on calcule les gradients

        if it % self.C == 0 : #actualisation du 2e réseau target Qhat
            self.Qhat.load_state_dict(self.Q.state_dict())


    # enregistrement de la transition pour exploitation par learn ulterieure
    def store(self, ob, action, new_ob, reward, done, it):
        # Si l'agent est en mode de test, on n'enregistre pas la transition
        if not self.test:
            # si on atteint la taille max d'episode en apprentissage, alors done ne devrait pas etre a true (episode pas vraiment fini dans l'environnement)
            if it == self.opt.maxLengthTrain:
                print("undone")
                done=False
            tr = (ob, action, reward, new_ob, done)
            self.lastTransition=tr #ici on n'enregistre que la derniere transition pour traitement immédiat, mais on pourrait enregistrer dans une structure de buffer (c'est l'interet de memory.py)
            _ = self.mem.store(self.lastTransition) #ajout dans la mémoire
    # retourne vrai si c'est le moment d'entraîner l'agent.
    # Dans cette version retourne vrai tous les freqoptim evenements
    # Mais on pourrait retourner vrai seulement si done pour s'entraîner seulement en fin d'épisode
    def timeToLearn(self, done):
        if self.test:
            return False
        self.nbEvents+=1
        return self.nbEvents%self.opt.freqOptim == 0

if __name__ == '__main__':
    env, config, outdir, logger = init('./configs/config_random_cartpole.yaml', "DQN/Cartpole")

    freqTest = config["freqTest"]
    freqSave = config["freqSave"]
    nbTest = config["nbTest"]
    env.seed(config["seed"])
    np.random.seed(config["seed"])
    episode_count = config["nbEpisodes"]

    agent = DQN_target_network(env, config) #DQN_1Net(env,config)

    rsum = 0
    mean = 0
    verbose = True
    itest = 0
    reward = 0
    done = False


    ######## BOUCLE POUR CREER LA MEMOIRE ALEATOIREMENT, PUIS ON FAIT LE FIT DU MODEL VIA LE LEARN ====> INUTILE
    # ob = env.reset()
    # ob = agent.featureExtractor.getFeatures(ob)
    # for i in range(agent.mem.mem_size): #taille de la mémoire:
    #     action = agent.action_space.sample()
    #     new_ob, reward, done, _ = env.step(action)
    #     new_ob = agent.featureExtractor.getFeatures(new_ob)
    #     tr = (ob, action, reward, new_ob, done)
    #     ob = new_ob
    #     _ = agent.mem.store(tr)  #ajout dans la mémoire
    #_, _, batch = agent.mem.sample(4)
    #print(torch.tensor(batch[0][0]).view(-1))
    #res = torch.from_numpy(np.vstack([b[1] for b in batch if b is not None])).float()
    #print(res)

    ######## REMPLISSAGE MEMOIRE ET APPRENTISSAGE
    for i in range(episode_count):
        checkConfUpdate(outdir, config)

        rsum = 0
        agent.nbEvents = 0
        ob = env.reset()

        # On souhaite afficher l'environnement (attention à ne pas trop afficher car ça ralentit beaucoup)
        if i % int(config["freqVerbose"]) == 0:
            verbose = True
        else:
            verbose = False

        # C'est le moment de tester l'agent
        if i % freqTest == 0 and i >= freqTest:  ##### Same as train for now
            print("Test time! ")
            mean = 0
            agent.test = True

        # On a fini cette session de test
        if i % freqTest == nbTest and i > freqTest:
            print("End of test, mean reward=", mean / nbTest)
            itest += 1
            logger.direct_write("rewardTest", mean / nbTest, itest)
            agent.test = False

        # C'est le moment de sauver le modèle
        if i % freqSave == 0:
            agent.save(outdir + "/save_" + str(i))

        j = 0
        if verbose:
            env.render()

        new_ob = agent.featureExtractor.getFeatures(ob)
        while True:
            if verbose:
                env.render()

            ob = new_ob
            action = agent.act(ob)
            new_ob, reward, done, _ = env.step(action)
            new_ob = agent.featureExtractor.getFeatures(new_ob)

            j+=1

            # Si on a atteint la longueur max définie dans le fichier de config
            if ((config["maxLengthTrain"] > 0) and (not agent.test) and (j == config["maxLengthTrain"])) or ( (agent.test) and (config["maxLengthTest"] > 0) and (j == config["maxLengthTest"])):
                done = True
                print("forced done!")

            agent.store(ob, action, new_ob, reward, done, j)
            rsum += reward

            if agent.timeToLearn(done):
                agent.learn(ob, action, new_ob, reward, done, i)
            if done: #si état terminal
                print(str(i) + " rsum=" + str(rsum) + ", " + str(j) + " actions ")
                logger.direct_write("reward", rsum, i)
                agent.nbEvents = 0
                mean += rsum
                rsum = 0

                break

    env.close()
