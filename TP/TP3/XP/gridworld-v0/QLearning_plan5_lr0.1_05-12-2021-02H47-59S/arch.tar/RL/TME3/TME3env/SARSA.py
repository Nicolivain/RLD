import matplotlib
matplotlib.use("TkAgg")
import gym
import gridworld
from gym import wrappers, logger
import numpy as np
import copy
from datetime import datetime
import os
from utils import *
import yaml


#ICI on utilisera les quantités Q plutôt que les V (values) : Q prend 2 arguments Q(s,a) car maintenant on ne connaît plus le mdp
# V était utile quand on connaissait notre carte de transitions et l'action qui maximisait le V à l'état suivant, maintenant on va explorer pour le savoir
# Relation : V(s) = max_{a \in A(s)} Q(s,a)


def epsilon_greedy(obs, epsilon):#dualité exploration/exploitation grâce au epsilon-greedy
    alea = np.random.rand()
    if alea > epsilon:  # exploitation
        return np.argmax(obs)
    else: # exploration
        return np.random.randint(len(obs))


class SARSA(object):
    '''Main difference is in the choice of the action, that comes before Qlearning'''

    def __init__(self, env, opt):
        self.opt=opt
        self.action_space = env.action_space
        self.env=env
        self.discount=opt.gamma
        self.alpha=opt.learningRate
        self.explo=opt.explo
        self.exploMode=opt.exploMode #0: epsilon greedy, 1: ucb
        self.sarsa=opt.sarsa
        self.modelSamples=opt.nbModelSamples
        self.test=False #True = période d'exploitation (de test) // False = on explore (on apprend)
        self.qstates = {}  # dictionnaire d'états rencontrés avec l'index associé pour se retrouver dans self.values (leur ordre d'apparition n'est pas chronologique)
        self.values = []   # contient, pour chaque numéro d'état, les qvaleurs des self.action_space.n actions possibles c'est la table Q(s,a)

    def save(self,file):
        #Si on veut stocker dans un fichier
       pass

    #enregistre cette observation dans la liste des états rencontrés si pas déjà présente
    #retourne l'identifiant associé à cet état
    def storeState(self,obs):
        observation = obs.dumps()
        s = str(observation)
        ss = self.qstates.get(s, -1) #get(s,-1) renvoie soit la valeur du dico en s soit -1

        # Si l'etat s jamais rencontré (i.e. ss = -1), on crée la case du dico dans self.qstates
        if ss < 0:
            ss = len(self.values) #nouvel index pour l'état rencontré
            self.qstates[s] = ss #qstates va permettre de stocker l'index de chaque état pour se repérer dans self.values qui contient les Qvalues
            self.values.append(np.ones(self.action_space.n) * 1.0) # Optimism faced to uncertainty (on commence avec des valeurs à 1 pour favoriser l'exploration)

        return ss

    def act(self, obs):
        if self.test : #en mode exploitation, on suit notre politique (on va vers le max des qvalues)
            return np.argmax(self.values[obs])
        else : #en mode exploration, on utilise le epsilon-greedy
            return epsilon_greedy(self.values[obs], self.explo)


    def store(self, ob, action, new_ob, new_action, reward, done, it): #permet de stocker les info de notre nouvelle situation après action
        if self.test:
            return
        self.last_source=ob
        self.last_action=action
        self.new_action = new_action
        self.last_dest=new_ob
        self.last_reward=reward
        if it == self.opt.maxLengthTrain:   # si on a atteint la taille limite, ce n'est pas un vrai done de l'environnement
            done = False
        self.last_done=done


    def learn(self, done):
        self.values[self.last_source][self.last_action] += self.alpha*(self.last_reward + self.discount*self.values[self.last_dest][self.new_action]-self.values[self.last_source][self.last_action])
    #mise à jour du Q
    #Q(s,a) = Q(s,a) + alpha(r + gamma*max_{a'}[Q(s',a') - Q(s,a)])



if __name__ == '__main__':
    env,config,outdir,logger=init('./configs/config_qlearning_gridworld.yaml',"QLearning")
    freqTest = 200#config["freqTest"]
    freqSave = config["freqSave"]
    nbTest = config["nbTest"]
    env.seed(config["seed"])
    np.random.seed(config["seed"])
    episode_count = 6000#config["nbEpisodes"]

    agent = SARSA(env, config)

    agent.explo = 0.1
    rsum = 0
    mean = 0
    verbose = True
    itest = 0
    reward = 0
    done = False
    nb = 0
    for i in range(episode_count):
        checkConfUpdate(outdir, config)  # permet de changer la config en cours de run
        rsum = 0
        agent.nbEvents = 0
        ob = env.reset()

        if (i > 0 and i % int(config["freqVerbose"]) == 0) :#fréquence d'affichage
            verbose = True
        else :
            verbose = False

        if i % freqTest == 0 and i >= freqTest :  ##### Si agent.test alors retirer l'exploration
            print("Test time! ")
            mean = 0
            agent.test = True

        if i % freqTest == nbTest and i > freqTest :
            print("End of test, mean reward=", mean / nbTest)
            itest += 1
            logger.direct_write("rewardTest", mean / nbTest, itest)
            agent.test = False

        if i % freqSave == 0:
            agent.save(outdir + "/save_" + str(i))

        j = 0
        if verbose :
            env.render()
        new_ob = agent.storeState(ob)
        action = agent.act(new_ob) #action choisie selon Q en espilon-greedy
        while True:
            if verbose :
                env.render()
            ob = new_ob
            new_ob, reward, done, _ = env.step(action) #exécution de l'action décidée avant le while et observation de r et s'
            new_ob = agent.storeState(new_ob) #transformation de new_ob en index approprié
            new_action = agent.act(new_ob) #choix de a_{t+1} en fonction de Q (epsilon-greedy)

            j+=1

            if ((config["maxLengthTrain"] > 0) and (not agent.test) and (j == config["maxLengthTrain"])) or ( (agent.test) and (config["maxLengthTest"] > 0) and (j == config["maxLengthTest"])):
                done = True
                print("forced done!")

            agent.store(ob, action, new_ob, new_action, reward, done, j) #on stocke ce que l'on vient d'observer
            agent.learn(done) #on demande à l'agent d'apprendre
            rsum += reward
            ob = new_ob
            action = new_action
            if done: #si épisode terminé
                print(str(i) + " rsum=" + str(rsum) + ", " + str(j) + " actions ")
                logger.direct_write("reward", rsum, i)
                mean += rsum
                break
        agent.explo *= 0.999
    env.close()
